document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("loginForm");

    form.addEventListener("submit", (e) => {
        e.preventDefault(); 

        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();

        
        const correctUser = "admin";
        const correctPass = "1234";

        if (username === correctUser && password === correctPass) {
            
            window.location.href = "index.html";
        } else {
            
            alert("Invalid username or password!");
        }
    });
});


    const toggle = document.getElementById("toggleMode");
    toggle.addEventListener("click", () => {
      document.body.classList.toggle("dark");
      toggle.textContent = document.body.classList.contains("dark")
        ? "☀️ Light Mode"
        : "🌙 Dark Mode";
    });
