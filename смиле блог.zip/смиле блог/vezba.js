const orders = [
  { orderNumber: 910101, totalOrdVal: 120.50, createdAt: '2025-12-17' },
  { orderNumber: 910102, totalOrdVal: 89.99,  createdAt: '2025-12-17' },
  { orderNumber: 910103, totalOrdVal: 45.00,  createdAt: '2025-12-18' },
  { orderNumber: 910104, totalOrdVal: 230.00, createdAt: '2025-12-17' },
  { orderNumber: 910105, totalOrdVal: 15.75,  createdAt: '2025-12-18' },
  { orderNumber: 910106, totalOrdVal: 310.20, createdAt: '2025-12-19' },
  { orderNumber: 910107, totalOrdVal: 67.40,  createdAt: '2025-12-17' },
  { orderNumber: 910108, totalOrdVal: 99.99,  createdAt: '2025-12-19' }
];
const date = '2025-12-17'


 function getOrdersByDate(date) {
   let orderdate = orders.filter(order => order.createdAt === date);
   console.log("First+++++++", orderdate)
 }
 getOrdersByDate(date);


 function getTotalOrderValue() {
   let ordersum = orders.reduce((sum, order) => sum + order.totalOrdVal, 0);
   console.log("Second++++++",   ordersum)

 } 
getTotalOrderValue();


function getMaxOrder(orders) {
    const order = orders.length;   
  console.log("Third++++", order);
}
getMaxOrder(orders);


