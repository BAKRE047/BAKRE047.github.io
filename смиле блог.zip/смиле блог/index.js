
const cards = document.querySelectorAll(".pixel-card");


const STAGGER_DELAY = 300;

const observer = new IntersectionObserver(
  entries => {
    
    const visibleCards = entries
      .filter(entry => entry.isIntersecting)
      .map(entry => entry.target);

    visibleCards.forEach((card, index) => {
      
      card.classList.remove("pulse");

      
      setTimeout(() => {
        card.classList.add("pulse");
      }, index * STAGGER_DELAY);
    });

    
    entries
      .filter(entry => !entry.isIntersecting)
      .forEach(entry => {
        entry.target.classList.remove("pulse");
      });
  },
  { threshold: 0.3 }
);


cards.forEach(card => observer.observe(card));
